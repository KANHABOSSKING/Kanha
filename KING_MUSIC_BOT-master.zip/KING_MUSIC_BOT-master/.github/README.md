<h2 align="center">
    ──「 KING ダ MUSIC 」──
</h2>

<p align="center">
  <img src="https://graph.org/file/9a6da16d52fdb628901a6.jpg">
</p>


</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/KING0712/KINGXMUSIC_BOT"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʟᴏᴄᴀʟ ʜᴏsᴛ/ ᴠᴘs 」─
</h3>

- Get your [Necessary Variables](https://github.com/KING0712/KING_MUSIC_BOT/blob/master/sample.env)
- Upgrade and Update by :
`sudo apt-get update && sudo apt-get upgrade -y`
- Install Ffmpeg by :
`sudo apt-get install python3-pip ffmpeg -y`
- Install required packages by :
`sudo apt-get install python3-pip -y`
- Install pip by :
`sudo pip3 install -U pip`
- Install Node js by :
`curl -fssL https://deb.nodesource.com/setup_19.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm`
- Clone the repository by :
`git clone https://github.com/KING0712/KING_MUSIC_BOT && cd AnonXMusic`
- Install requirements by :
`pip3 install -U -r requirements.txt`
- Fill your variables in the env by :
`vi sample.env`<br>
Press `I` on the keyboard for editing env<br>
Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br>
- Rename the env file by :
`mv sample.env .env`
- Install tmux to keep running your bot when you close the terminal by :
`sudo apt install tmux && tmux`
- Finally run the bot by :
`bash start`
- For getting out from tmux session : Press `Ctrl+b` and then `d`<br>
━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 OWNER 」─
</h3>

<p align="center">
<a href="https://telegram.me/l_MR_ll_KING_l"><img src="https://img.shields.io/badge/-OWNER%20ID-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>


